package com.hcl.hclassessment2.model;

import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class CustomerId implements Serializable {
    private String idValue;

    public CustomerId() {}

    public CustomerId(String idValue) {
        this.idValue = idValue;
    }

    public String getIdValue() { return idValue; }
    public void setIdValue(String idValue) { this.idValue = idValue; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CustomerId that = (CustomerId) o;
        return Objects.equals(idValue, that.idValue);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idValue);
    }
}
