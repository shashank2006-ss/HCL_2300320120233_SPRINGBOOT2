package com.hcl.hclassessment2.repository;

import com.hcl.hclassessment2.model.Cart;
import com.hcl.hclassessment2.model.CustomerId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface CartRepository extends JpaRepository<Cart, Long> {
    Optional<Cart> findByCustomer_Id(CustomerId customerId);
}
