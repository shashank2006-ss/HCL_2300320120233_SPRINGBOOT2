package com.hcl.hclassessment2.controller;

import com.hcl.hclassessment2.dto.OrderItemRequest;
import com.hcl.hclassessment2.model.Cart;
import com.hcl.hclassessment2.model.CustomerOrder;
import com.hcl.hclassessment2.model.Product;
import com.hcl.hclassessment2.repository.ProductRepository;
import com.hcl.hclassessment2.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class ShoppingController {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private OrderService orderService;

    // 1. BROWSE PRODUCTS
    @GetMapping("/products")
    public List<Product> browseProducts() {
        return productRepository.findAll();
    }

    // 2. ADD ITEM TO SYSTEM CART
    @PostMapping("/cart/add")
    public ResponseEntity<?> addToCart(@RequestParam String customerId,
                                       @RequestBody OrderItemRequest itemRequest) {
        try {
            Cart updatedCart = orderService.addToCart(customerId, itemRequest);
            return new ResponseEntity<>(updatedCart, HttpStatus.OK);
        } catch (RuntimeException ex) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
        }
    }

    // 3. PLACE ORDER FROM CART
    @PostMapping("/orders/checkout")
    public ResponseEntity<?> checkout(@RequestParam String customerId) {
        try {
            CustomerOrder completedOrder = orderService.checkoutCart(customerId);
            return new ResponseEntity<>(completedOrder, HttpStatus.CREATED);
        } catch (RuntimeException ex) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
        }
    }

    // 4. CANCEL ELIGIBLE ORDER
    @PutMapping("/orders/{id}/cancel")
    public ResponseEntity<String> cancelOrder(@PathVariable Long id) {
        try {
            orderService.cancelOrder(id);
            return ResponseEntity.ok("Order has been successfully cancelled and stock replenished.");
        } catch (IllegalStateException ex) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(ex.getMessage());
        } catch (RuntimeException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
        }
    }
}
