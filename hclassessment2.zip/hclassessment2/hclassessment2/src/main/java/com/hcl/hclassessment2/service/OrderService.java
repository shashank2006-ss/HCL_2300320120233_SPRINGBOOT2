package com.hcl.hclassessment2.service;

import com.hcl.hclassessment2.dto.OrderItemRequest;
import com.hcl.hclassessment2.model.*;
import com.hcl.hclassessment2.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class OrderService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private CustomerOrderRepository customerOrderRepository;

    @Transactional
    public Cart addToCart(String customerIdVal, OrderItemRequest request) {
        CustomerId customerId = new CustomerId(customerIdVal);
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        Product product = productRepository.findById(request.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found"));

        Cart cart = cartRepository.findByCustomer_Id(customerId).orElseGet(() -> {
            Cart newCart = new Cart();
            newCart.setCustomer(customer);
            return cartRepository.save(newCart);
        });

        Optional<CartItem> existingItem = cart.getItems().stream()
                .filter(item -> item.getProduct().getId().equals(product.getId()))
                .findFirst();

        if (existingItem.isPresent()) {
            existingItem.get().setQuantity(existingItem.get().getQuantity() + request.getQuantity());
        } else {
            CartItem newItem = new CartItem();
            newItem.setCart(cart);
            newItem.setProduct(product);
            newItem.setQuantity(request.getQuantity());
            cart.getItems().add(newItem);
        }

        return cartRepository.save(cart);
    }

    @Transactional
    public CustomerOrder checkoutCart(String customerIdVal) {
        CustomerId customerId = new CustomerId(customerIdVal);
        Cart cart = cartRepository.findByCustomer_Id(customerId)
                .orElseThrow(() -> new RuntimeException("No active shopping cart found for customer"));

        if (cart.getItems().isEmpty()) {
            throw new RuntimeException("Shopping cart is empty");
        }

        CustomerOrder order = new CustomerOrder();
        order.setCustomerId(customerId);
        order.setOrderDate(LocalDateTime.now());
        order.setStatus(CustomerOrder.OrderStatus.PENDING);

        for (CartItem cartItem : cart.getItems()) {
            Product product = cartItem.getProduct();

            if (product.getStockQuantity() < cartItem.getQuantity()) {
                throw new RuntimeException("Insufficient stock availability for product: " + product.getName());
            }

            product.setStockQuantity(product.getStockQuantity() - cartItem.getQuantity());
            productRepository.save(product);

            OrderItem orderItem = new OrderItem();
            orderItem.setCustomerOrder(order);
            orderItem.setProduct(product);
            orderItem.setQuantity(cartItem.getQuantity());
            orderItem.setPrice(product.getPrice());
            order.getItems().add(orderItem);
        }

        order.calculateTotal();

        // Clear out items from the database session cart post successful execution checkout
        cart.getItems().clear();
        cartRepository.save(cart);

        return customerOrderRepository.save(order);
    }

    @Transactional
    public CustomerOrder cancelOrder(Long orderId) {
        CustomerOrder order = customerOrderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order records not found"));

        if (order.getStatus() != CustomerOrder.OrderStatus.PENDING) {
            throw new IllegalStateException("Only orders in PENDING status are eligible for cancellation.");
        }

        for (OrderItem item : order.getItems()) {
            Product product = item.getProduct();
            product.setStockQuantity(product.getStockQuantity() + item.getQuantity());
            productRepository.save(product);
        }

        order.setStatus(CustomerOrder.OrderStatus.CANCELLED);
        return customerOrderRepository.save(order);
    }
}
