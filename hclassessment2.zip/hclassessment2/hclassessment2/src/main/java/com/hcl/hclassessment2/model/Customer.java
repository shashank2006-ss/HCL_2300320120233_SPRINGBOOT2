package com.hcl.hclassessment2.model;

import jakarta.persistence.*;

@Entity
@Table(name = "customers")
public class Customer {

    @EmbeddedId
    private CustomerId id;

    private String name;
    private String email;

    @OneToOne(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    private Cart cart;

    public Customer() {}

    public CustomerId getId() { return id; }
    public void setId(CustomerId id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public Cart getCart() { return cart; }
    public void setCart(Cart cart) { this.cart = cart; }
}
